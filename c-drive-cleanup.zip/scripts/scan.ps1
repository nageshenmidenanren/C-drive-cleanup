$ErrorActionPreference = "SilentlyContinue"

$categories = @()

function Get-DirSize {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return 0 }
    try {
        $size = (Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue |
                 Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if ($null -eq $size) { return 0 }
        return [math]::Round($size / 1MB, 2)
    } catch {
        return 0
    }
}

function Get-RecycleBinSize {
    try {
        $size = (Get-ChildItem -Path "C:\`$Recycle.Bin" -Recurse -Force -ErrorAction SilentlyContinue |
                 Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
        if ($null -eq $size) { return 0 }
        return [math]::Round($size / 1MB, 2)
    } catch {
        return 0
    }
}

# 1. System Temp
$categories += [PSCustomObject]@{
    id = 1
    name = "System Temp"
    path = "$env:SystemRoot\Temp"
    sizeMB = (Get-DirSize "$env:SystemRoot\Temp")
}

# 2. User Temp
$categories += [PSCustomObject]@{
    id = 2
    name = "User Temp"
    path = "$env:TEMP"
    sizeMB = (Get-DirSize "$env:TEMP")
}

# 3. Prefetch
$categories += [PSCustomObject]@{
    id = 3
    name = "Windows Prefetch"
    path = "$env:SystemRoot\Prefetch"
    sizeMB = (Get-DirSize "$env:SystemRoot\Prefetch")
}

# 4. Windows Update Cache
$categories += [PSCustomObject]@{
    id = 4
    name = "Windows Update Cache"
    path = "$env:SystemRoot\SoftwareDistribution\Download"
    sizeMB = (Get-DirSize "$env:SystemRoot\SoftwareDistribution\Download")
}

# 5. Thumbnail Cache
$categories += [PSCustomObject]@{
    id = 5
    name = "Thumbnail Cache"
    path = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
    sizeMB = (Get-DirSize "$env:LOCALAPPDATA\Microsoft\Windows\Explorer")
}

# 6. Recycle Bin
$categories += [PSCustomObject]@{
    id = 6
    name = "Recycle Bin"
    path = "C:\`$Recycle.Bin"
    sizeMB = (Get-RecycleBinSize)
}

# 7. Crash Dumps
$categories += [PSCustomObject]@{
    id = 7
    name = "Crash Dumps"
    path = "$env:LOCALAPPDATA\CrashDumps"
    sizeMB = (Get-DirSize "$env:LOCALAPPDATA\CrashDumps")
}

# 8. Browser Cache
$chromeCacheSize = (Get-DirSize "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache")
$edgeCacheSize = (Get-DirSize "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache")
$categories += [PSCustomObject]@{
    id = 8
    name = "Browser Cache (Chrome/Edge)"
    path = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache"
    sizeMB = [math]::Round(($chromeCacheSize + $edgeCacheSize), 2)
}

$total = ($categories | Measure-Object -Property sizeMB -Sum).Sum
$total = [math]::Round($total, 2)

$result = @{
    totalMB = $total
    categories = $categories
}

$result | ConvertTo-Json -Depth 3
