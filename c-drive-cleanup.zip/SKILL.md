---
name: C-Drive Cleanup
description: This skill scans and cleans redundant files on Windows C drive to free up disk space. This skill should be used when the user wants to clean up C drive, free disk space, remove temporary files, or clear system cache on Windows.
---

# C-Drive Cleanup

Scan and clean redundant files on Windows C drive to reclaim disk space. Perform a safe, multi-layer cleanup covering system temp files, user cache, browser data, Windows Update leftovers, and more.

## Quick Start

Ask the user: "要清理 C 盘吗？我会先扫描分析，再由你确认后执行清理。"

Then run the scan script to analyze disk usage, present a report, and wait for user confirmation before deleting anything.

## Instructions

To use this skill effectively, follow these steps:

1. **Analyze disk usage**
   - Run the PowerShell scan script to identify junk file locations and their sizes
   - The scan covers 8 major categories (see below)
   - Present a summary table showing size per category and total reclaimable space

2. **Present cleanup plan and confirm**
   - Show the user the scan results with sizes
   - Ask which categories to clean (default: all except browser cache)
   - **Never delete without explicit user confirmation**

3. **Execute cleanup**
   - Run the cleanup script for the selected categories
   - Report what was deleted and how much space was reclaimed
   - Skip files that are locked/in-use (report them separately)

## Scan Categories

| # | Category | Location |
|---|----------|----------|
| 1 | System Temp | `C:\Windows\Temp` |
| 2 | User Temp | `%TEMP%` (`%LOCALAPPDATA%\Temp`) |
| 3 | Windows Prefetch | `C:\Windows\Prefetch` |
| 4 | Windows Update Cache | `C:\Windows\SoftwareDistribution\Download` |
| 5 | Thumbnail Cache | `%LOCALAPPDATA%\Microsoft\Windows\Explorer` |
| 6 | Recycle Bin | `$Recycle.Bin` |
| 7 | Crash Dumps | `%LOCALAPPDATA%\CrashDumps` |
| 8 | Browser Cache (Chrome/Edge) | `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache` / `%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache` |

## Usage

### Step 1: Scan

Ask Claude to run the scan. Claude should execute:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\MSI-PC\.claude\skills\c-drive-cleanup\scripts\scan.ps1"
```

This outputs a JSON report with sizes per category.

### Step 2: Review and Confirm

Claude will show the results and ask you which categories to clean.

### Step 3: Clean

Claude executes cleanup for approved categories:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\Users\MSI-PC\.claude\skills\c-drive-cleanup\scripts\cleanup.ps1" -Categories "1,2,3,4,5,6,7"
```

## Best Practices

Do This:
- Always scan first, clean second
- Show sizes before deleting so the user can prioritize
- Skip files currently in-use (locked by processes)
- Keep a log of what was deleted

Avoid This:
- Never clean without user confirmation
- Never delete browser data without explicit opt-in (users may lose session info)
- Never touch `C:\Windows\System32`, `C:\Program Files`, or user documents

## Common Issues

### Issue: Access denied errors

Some temp files are locked by running processes. These will be skipped automatically.

### Issue: Minimal space reclaimed

Windows may already have auto-cleaned. Try running Disk Cleanup (`cleanmgr`) for deeper system cleanup, or check for large installed programs to uninstall manually.

## Limitations

- Windows only (uses PowerShell and Windows-specific paths)
- Requires standard user permissions (no admin needed for most cleanup)
- Cannot clean files locked by active processes
